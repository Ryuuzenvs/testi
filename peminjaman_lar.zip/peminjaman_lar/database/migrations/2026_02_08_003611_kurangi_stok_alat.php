<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
//trig
        //db:unpre "" triger name. where, ins tabel  for row 
// begin
// upd tabel, set var stck,
//end

DB::unprepared("
    CREATE TRIGGER kurangi_stok_alat
    AFTER INSERT ON loans
    FOR EACH ROW
    BEGIN
        UPDATE tools SET stock = stock - 1 WHERE id = NEW.tool_id;
    END
");
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
