<?php $__env->startSection('content'); ?>
<h3>Manajemen Peminjaman (Petugas)</h3>
<table class="table table-bordered bg-white">
    <thead>
        <tr>
            <th>Peminjam</th>
            <th>Alat</th>
            <th>Tgl Pinjam</th>
            <th>deadline</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($l->borrower->username); ?></td>
<td><?php echo e($l->tool->name_tools ?? 'Alat Dihapus'); ?></td>
            <td>
    <?php echo e(\Carbon\Carbon::parse($l->loan_date)->format('d M Y')); ?>

            </td>
<td>
    <span class="badge <?php echo e(now() > \Carbon\Carbon::parse($l->date_loan)->addDays(3) ? 'bg-danger' : 'bg-info'); ?>">
        <?php echo e(\Carbon\Carbon::parse($l->loan_date)->addDays(3)->format('d M Y')); ?>

    </span>
</td>
            <td>
                <span class="badge <?php echo e($l->status == 'pending' ? 'bg-warning' : ($l->status == 'borrow' ? 'bg-info' : 'bg-success')); ?>">
                    <?php echo e($l->status); ?>

                </span>
            </td>
            <td>
                <?php if($l->status == 'pending'): ?>
                    <form action="<?php echo e(route('loans.approve', $l->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <button class="btn btn-sm btn-primary">Approve</button>
                    </form>
                <?php elseif($l->status == 'borrow'): ?>
                    <form action="<?php echo e(route('loans.return', $l->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <button class="btn btn-sm btn-success">Terima Kembali</button>
                    </form>
                <?php else: ?>
                    <span class="text-muted">Selesai (Denda: Rp.<?php echo e($l->penalty); ?>)</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a href="<?php echo e(route('officer.report')); ?>" class="btn btn-primary">cetak laporan</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/petugas/index.blade.php ENDPATH**/ ?>