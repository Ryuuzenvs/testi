<?php $__env->startSection('content'); ?>
<div class="card">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

<div class="card-header d-flex justify-content-between">

<h5>Daftar Kategori</h5>
<a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.dashboard')); ?>"><i class='fas fa-arrow-left'></i> </a>
</div>

<div class="card-body">
<table class="table table-striped text-center">
<thead>

<tr>
<th>Kategori</th>
<th>Aksi</th>
</tr>

</thead>

<tbody>
<?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
<td> <?php echo e($c->nama_kategori); ?></td>
<td>
<div class="mb-2">
<form method="post" action="<?php echo e(route('category.destroy', $c->id)); ?>">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button class="btn btn-danger btn-sm"><i class='fa-solid fa-trash-can'></i></button>
<a href="<?php echo e(route('category.edit', $c->id)); ?>" class="btn btn-warning btn-sm"><i class='fa-solid fa-pen-to-square'></i></a>
</form>

</div>
</td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
<td colspan=3 class="text-center">kosong</td>
</td>
<?php endif; ?>
</tbody>
<a class="btn btn-primary btn-sm" href="<?php echo e(route('category.create')); ?>"><i class='fa-solid fa-plus'></i></a>
</table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>