<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('admin.loans.update', $loan->id)); ?>" method="POST">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    
    <label>Jumlah Denda</label>
    <input type="number" name="penalty" value="<?php echo e($loan->penalty); ?>" class="form-control">

    <label>Status</label>
    <select name="status" class="form-control">
        <option value="pending" <?php echo e($loan->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
        <option value="borrow" <?php echo e($loan->status == 'borrow' ? 'selected' : ''); ?>>Dipinjam</option>
        <option value="return" <?php echo e($loan->status == 'return' ? 'selected' : ''); ?>>Kembali</option>
    </select>


    <button type="submit" class="btn btn-primary mt-3">Simpan Perubahan</button>

</form>
    <a href="<?php echo e(route('admin.loans.index')); ?>" class="btn btn-danger">back</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/admin/loans/edit.blade.php ENDPATH**/ ?>