<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3 no-print">
    <h3>Laporan Peminjaman</h3>
<div class="card mb-3 no-print">
    <div class="card-body">
        <form action="<?php echo e(route('officer.report')); ?>" method="GET" class="row g-3 mt-2">
            <div class="col-md-4">
                <label>Tanggal Mulai</label>
                <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
            </div>
            <div class="col-md-4">
                <label>Tanggal Selesai</label>
                <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
            </div>
            <div class="col-md-2">
                <label>Status</label>
                <select name="status" class="form-control">
                    <option value="">Semua</option>
                    <option value="borrow" <?php echo e(request('status') == 'borrow' ? 'selected' : ''); ?>>Dipinjam</option>
                    <option value="return" <?php echo e(request('status') == 'return' ? 'selected' : ''); ?>>Kembali</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-success w-100">Filter</button>
            </div>
        </form>
    </div>
</div>
    <button onclick="window.print()" class="btn btn-primary">Cetak Laporan (PDF)</button>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Peminjam</th>
                    <th>Alat</th>
                    <th>Tgl Pinjam</th>
                    <th>Tgl Kembali</th>
                    <th>Status</th>
                    <th>Denda</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($r->borrower->username); ?></td>
                    <td><?php echo e($r->tool->name_tools ?? 'alat dihapus'); ?></td>
                    <td><?php echo e($r->loan_date); ?></td>
                    <td><?php echo e($r->return_date ?? '-'); ?></td>
                    <td><?php echo e(strtoupper($r->status)); ?></td>
                    <td>Rp <?php echo e(number_format($r->penalty, 0, ',', '.')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
<a href="<?php echo e(route('officer.dashboard')); ?>" class="btn btn-danger">back</a>
    </div>

</div>

<style>

@media print {
    .no-print, .navbar, .btn, .footer {
        display: none !important;
    }
    .card {
        border: none !important;
        box-shadow: none !important;
    }
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/petugas/report.blade.php ENDPATH**/ ?>