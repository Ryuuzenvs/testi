<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between">
        <h5>Daftar User</h5>
        <a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.dashboard')); ?>"><i class='fa-solid fa-arrow-left'></i></a>
    </div>

    <div class="card-body">
        <a class="btn btn-primary btn-sm mb-3" href="<?php echo e(route('users.create')); ?>"><i class='fa-solid fa-plus'></i></a>
        
        <table class="table table-striped text-center">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th> 
                    <th>Role</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($u->username); ?></td>
                    <td><?php echo e($u->email); ?></td>
                    <td><span class="badge bg-secondary"><?php echo e(strtoupper($u->role)); ?></span></td>
                    <td>
    <?php if($u->id != auth()->id()): ?>
        <form method="post" action="<?php echo e(route('users.destroy', $u->id)); ?>?role=<?php echo e($u->role); ?>" style="display:inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger btn-sm" onclick="return confirm('Hapus user ini?')"><i class='fa-solid fa-trash-can'></i></button>
        </form>

        <a href="<?php echo e(route('users.edit', [$u->id, 'role' => $u->role])); ?>" class="btn btn-warning btn-sm"><i class='fa-solid fa-pen-to-square'></i></a>
    <?php else: ?>
        <span class="text-muted small italic">Logged In</span>
    <?php endif; ?>
</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">Kosong</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/admin/users/index.blade.php ENDPATH**/ ?>