<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">Daftar Alat Tersedia</div>
            <div class="card-body">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Nama Alat</th>
                            <th>Stok</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($t->name_tools ?? 'Alat Dihapus'); ?></td>
                            <td><span class="badge bg-info"><?php echo e($t->stock); ?></span></td>
                            <td>
                                <form action="<?php echo e(route('pinjam.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="tool_id" value="<?php echo e($t->id); ?>">
                                    <button type="submit" class="btn btn-sm btn-success">Pinjam</button>
                                </form>
                            </td>
                        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
<td colspan="5" class="text-center">kosong alatnya</td>
</tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-header bg-dark text-white">Pinjaman Saya</div>
            <div class="card-body">
                <ul class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $myloan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?php echo e($loan->tool->name_tools ?? 'Alat Dihapus'); ?> |
                        <?php echo e($loan->loan_date); ?>

                        <span class="badge bg-warning text-dark"><?php echo e($loan->status); ?></span>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="list-group-item text-center">Belum ada pinjaman</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/peminjam/index.blade.php ENDPATH**/ ?>