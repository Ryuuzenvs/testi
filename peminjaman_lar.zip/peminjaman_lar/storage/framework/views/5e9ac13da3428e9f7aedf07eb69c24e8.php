<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-body p-4">
        <h3 class="text-center mb-4">Edit User</h3>

        <form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
                <input type="hidden" name="role" value="<?php echo e($user->role); ?>">
            
            <div class="mb-3">
                <label class="form-label">Nama Lengkap</label>
                <input type="text" name="username" class="form-control" value="<?php echo e($user->username); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Password <small class="text-muted">(Kosongkan jika tidak ingin ganti)</small></label>
                <input type="password" name="password" class="form-control">
            </div>
            <div class="mb-3">
                <label class="form-label">Role</label>
                <select name="role" class="form-control" required>
                    <option>pilih role</option>
                    <option value="borrower" <?php echo e($user->role == 'borrower' ? 'selected' : ''); ?>>Peminjam</option>
                    <option value="officer" <?php echo e($user->role == 'officer' ? 'selected' : ''); ?>>Petugas</option>
                    <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Admin</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-warning">back</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>