<link href=<?php echo e(asset('bootstrap.min.css')); ?> rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('fas/css/all.min.css')); ?>">
<style>
 {
    outline: 1px solid red !important;
  } 
</style>

<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">

<div class="container">
	<?php
    // var guard login
    $user = auth()->guard('admin')->user() 
            ?? auth()->guard('officer')->user() 
            ?? auth()->guard('borrower')->user();
?>
<a class="navbar-brand" href="<?php echo e($user ? $user->dashboardUrl() : '#'); ?>">
    PinjamAlat
</a>

<div class="navbar-nav">
    <?php if(auth()->guard('admin')->check()): ?>
        <a class="nav-link" href="<?php echo e(route('category.index')); ?>">Category</a>
        <a class="nav-link" href="<?php echo e(route('tools.index')); ?>">Tool</a>
        <a class="nav-link" href="<?php echo e(route('users.index')); ?>">User</a>
        <a class="nav-link" href="<?php echo e(route('admin.loans.index')); ?>">Loan</a>
<a class="nav-link" href="<?php echo e(route('admin.logs.index')); ?>">Logs</a>
    <?php elseif(auth()->guard('officer')->check()): ?>
        <a class="nav-link" href="<?php echo e(route('officer.dashboard')); ?>">Dashboard</a>
        <a class="nav-link" href="<?php echo e(route('officer.report')); ?>">Laporan</a>
    <?php else: ?>
        <a class="nav-link" href="<?php echo e(route('borrower.dashboard')); ?>">My Loans</a>
    <?php endif; ?>
    <form action="<?php echo e(route('logout')); ?>" method="post" class="d-inline">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-link nav-link">Logout</button>
    </form>
</div>
</div>

</nav>

<div class="container">
<?php echo $__env->yieldContent('content'); ?>
</div>

</body>


<?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/app.blade.php ENDPATH**/ ?>