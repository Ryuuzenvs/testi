<link href={{ asset('bootstrap.min.css') }} rel="stylesheet">
{{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"> --}}
<link rel="stylesheet" href="{{ asset('fas/css/all.min.css') }}">
<style>
 {
    outline: 1px solid red !important;
  } 
</style>

<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">

<div class="container">
	@php
    // var guard login
    $user = auth()->guard('admin')->user() 
            ?? auth()->guard('officer')->user() 
            ?? auth()->guard('borrower')->user();
@endphp
<a class="navbar-brand" href="{{ $user ? $user->dashboardUrl() : '#' }}">
    PinjamAlat
</a>

<div class="navbar-nav">
    @if(auth()->guard('admin')->check())
        <a class="nav-link" href="{{ route('category.index') }}">Category</a>
        <a class="nav-link" href="{{ route('tools.index') }}">Tool</a>
        <a class="nav-link" href="{{ route('users.index') }}">User</a>
        <a class="nav-link" href="{{ route('admin.loans.index') }}">Loan</a>
<a class="nav-link" href="{{ route('admin.logs.index') }}">Logs</a>
    @elseif(auth()->guard('officer')->check())
        <a class="nav-link" href="{{ route('officer.dashboard') }}">Dashboard</a>
        <a class="nav-link" href="{{ route('officer.report') }}">Laporan</a>
    @else
        <a class="nav-link" href="{{ route('borrower.dashboard') }}">My Loans</a>
    @endif
    <form action="{{ route('logout') }}" method="post" class="d-inline">
        @csrf
        <button type="submit" class="btn btn-link nav-link">Logout</button>
    </form>
</div>
</div>

</nav>

<div class="container">
@yield('content')
</div>

</body>


