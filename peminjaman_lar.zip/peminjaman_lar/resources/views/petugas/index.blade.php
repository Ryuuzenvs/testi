@extends('app')

@section('content')
<h3>Manajemen Peminjaman (Petugas)</h3>
<table class="table table-bordered bg-white">
    <thead>
        <tr>
            <th>Peminjam</th>
            <th>Alat</th>
            <th>Tgl Pinjam</th>
            <th>deadline</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @foreach($loans as $l)
        <tr>
            <td>{{ $l->borrower->username }}</td>
<td>{{ $l->tool->name_tools ?? 'Alat Dihapus' }}</td>
            <td>
    {{ \Carbon\Carbon::parse($l->loan_date)->format('d M Y') }}
            </td>
<td>
    <span class="badge {{ now() > \Carbon\Carbon::parse($l->date_loan)->addDays(3) ? 'bg-danger' : 'bg-info' }}">
        {{ \Carbon\Carbon::parse($l->loan_date)->addDays(3)->format('d M Y') }}
    </span>
</td>
            <td>
                <span class="badge {{ $l->status == 'pending' ? 'bg-warning' : ($l->status == 'borrow' ? 'bg-info' : 'bg-success') }}">
                    {{ $l->status }}
                </span>
            </td>
            <td>
                @if($l->status == 'pending')
                    <form action="{{ route('loans.approve', $l->id) }}" method="POST">
                        @csrf @method('PUT')
                        <button class="btn btn-sm btn-primary">Approve</button>
                    </form>
                @elseif($l->status == 'borrow')
                    <form action="{{ route('loans.return', $l->id) }}" method="POST">
                        @csrf @method('PUT')
                        <button class="btn btn-sm btn-success">Terima Kembali</button>
                    </form>
                @else
                    <span class="text-muted">Selesai (Denda: Rp.{{ $l->penalty }})</span>
                @endif
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
<a href="{{route('officer.report')}}" class="btn btn-primary">cetak laporan</a>
@endsection
