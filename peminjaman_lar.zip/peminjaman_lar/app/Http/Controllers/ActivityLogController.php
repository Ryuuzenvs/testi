<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;

class ActivityLogController extends Controller
{
    public function index()
    {
        // get logger by pag 20
        $logs = ActivityLog::latest()->paginate(20);
        
        return view('admin.logs.index', compact('logs'));
    }
}
